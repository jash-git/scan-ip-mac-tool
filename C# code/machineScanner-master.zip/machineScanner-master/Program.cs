﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;

namespace machineScanner
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("min:"); String min = Console.ReadLine();
            Console.WriteLine("max:"); String max = Console.ReadLine();

            PingPong pp = new PingPong();
            pp.runPing(min, max);
        }
    }

    class PingPong
    {
        private String getIP(String machineName)
        {
            List<IPAddress> ipData = Dns.GetHostAddresses(machineName).ToList();
            String ip = "";

            foreach (var item in ipData)
            {
                if (item.ToString().Contains("192.168"))                // get the ip only pls
                {
                    ip = item.ToString();
                }
            }
            return ip;
        }

        private String getMachine(String ipAddress)                     // get the responding machine name
        {
            String machineName = String.Empty;
            String[] temp;
            try
            {
                IPHostEntry hostEntry = Dns.GetHostEntry(ipAddress);
                temp = hostEntry.HostName.Split('.');
                machineName = temp[0];
            }
            catch (Exception exMachine)
            {
                Console.WriteLine(" flag:exMachine:" + exMachine.Message);
            }
            return machineName;
        }


        private uint stringToIP(string ip)                              // string to bytes magic
        {
            string[] numbers = ip.Split('.');

            uint x1 = (uint)(Convert.ToByte(numbers[0]) << 24);
            uint x2 = (uint)(Convert.ToByte(numbers[1]) << 16);
            uint x3 = (uint)(Convert.ToByte(numbers[2]) << 8);
            uint x4 = (uint)(Convert.ToByte(numbers[3]));

            return x1 + x2 + x3 + x4;
        }

        private static string ipToString(uint ip)                       // bytes to string magic
        {
            string s1 = ((ip & 0xff000000) >> 24).ToString() + ".";
            string s2 = ((ip & 0x00ff0000) >> 16).ToString() + ".";
            string s3 = ((ip & 0x0000ff00) >> 8).ToString() + ".";
            string s4 = (ip & 0x000000ff).ToString();

            string ip2 = s1 + s2 + s3 + s4;
            return ip2;
        }

        public void runPing(String min, String max)
        {
            Console.WriteLine("Running ping...");

            String pingDATA = "";
            uint ipRangeMin = stringToIP(min);
            uint ipRangeMax = stringToIP(max);

            Ping ping = new Ping();
            for (uint ip = ipRangeMin; ip <= ipRangeMax; ip++)
            {
                String myIP = ipToString(ip);
                PingReply getPong = ping.Send(IPAddress.Parse(myIP));

                if (getPong.Status == IPStatus.Success)
                {
                    String machine = "";
                    if ((machine = getMachine(myIP)) != "")
                    {
                        pingDATA += "NAME:" + machine + ":IP:" + myIP + "\n";
                        Console.WriteLine("Machine name: {0} -> {1}\n", machine, myIP);
                    }
                }
            }
        }
    }
}
