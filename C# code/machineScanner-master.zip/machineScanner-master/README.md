# machineScanner
Scans machines in a ip range

- This is stupid code with stupid purposes. No big deal here.
- If you're able to scan your external ip range, drop this thing and go secure your ports.
- Don't try this at work?!
